﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Media;
using System.Threading;

class CyberSecurityChatbot
{
    static Random random = new Random();
    static string userName = "";
    static string userInterest = "";

    static void Main()
    {
        Console.Clear();
        PlayVoiceGreeting();
        DisplayAsciiArt();
        userName = GetUserName();
        GreetUser(userName);
        RunChatbot();
    }

    static void PlayVoiceGreeting()
    {
        try
        {
            if (File.Exists("greeting.wav"))
            {
                SoundPlayer player = new SoundPlayer("greeting.wav");
                player.Load();
                player.PlaySync();
            }
            else
            {
                Console.WriteLine("Greeting audio file not found.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error playing audio: " + ex.Message);
        }
    }

    static void DisplayAsciiArt()
    {
        string asciiArt = @"
        ********************************
        *          /\_/\              *
        *         ( o.o )  CYBERSECURITY AWARENESS BOT  *
        *          > ^ <              *
        ********************************";

        Console.ForegroundColor = ConsoleColor.Green;
        Console.WriteLine(asciiArt);
        Console.ResetColor();
        Thread.Sleep(500);
    }

    static string GetUserName()
    {
        Console.ForegroundColor = ConsoleColor.Yellow;
        Console.Write("Please enter your name: ");
        Console.ResetColor();
        string name = Console.ReadLine()?.Trim();
        while (string.IsNullOrEmpty(name))
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("Invalid input. Please enter a valid name: ");
            Console.ResetColor();
            name = Console.ReadLine()?.Trim();
        }
        return name;
    }

    static void GreetUser(string name)
    {
        Console.ForegroundColor = ConsoleColor.Cyan;
        Console.WriteLine($"\n========================================");
        Console.WriteLine($"Hello {name}, welcome to the Cybersecurity Awareness Bot!");
        Console.WriteLine("How can I assist you today?");
        Console.WriteLine($"========================================\n");
        Console.ResetColor();
        Thread.Sleep(500);
    }

    static void RunChatbot()
    {
        Dictionary<string, string> staticResponses = new Dictionary<string, string>
        {
            {"how are you", "I'm just a bot, but I'm here to help you with cybersecurity!"},
            {"what’s your purpose", "I'm here to provide cybersecurity awareness and safety tips."},
            {"what can I ask you about", "You can ask me about password safety, phishing, and safe browsing."},
            {"password safety", "Use strong, unique passwords and enable two-factor authentication."},
            {"tell me how to avoid scam", "Make sure your password is strong and never share it with anyone."},
            {"how to ensure privacy", "Use unique passwords, avoid using personal info, and never save login details on shared devices."},
            {"safe browsing", "Always use HTTPS websites and keep your software up to date."}
        };

        Dictionary<string, List<string>> randomResponses = new Dictionary<string, List<string>>
        {
            { "phishing", new List<string>
                {
                    "Be cautious of emails asking for personal information. Scammers often disguise themselves as trusted organisations.",
                    "Never click suspicious links. Always verify the sender's email address.",
                    "Avoid downloading attachments from unknown sources—they might contain malware.",
                    "Phishing emails often create a sense of urgency. Stay calm and verify first."
                }
            },
            { "password", new List<string> {
                "Make sure to use strong, unique passwords for each account.",
                "Avoid using personal details in your passwords.",
                "Use a password manager to keep your credentials safe." }
            },
            { "scam", new List<string> {
                "Be cautious of unsolicited emails asking for personal info.",
                "Don't click on suspicious links — verify before trusting.",
                "Scammers often disguise themselves as trusted organisations." }
            },
            { "privacy", new List<string> {
                "Limit the personal info you share online.",
                "Review app permissions regularly.",
                "Use secure, encrypted messaging services when possible." }
            },
        };

        while (true)
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write("\nAsk me a question (or type 'exit' to quit): ");
            Console.ResetColor();
            string userInput = Console.ReadLine()?.ToLower().Trim();

            if (string.IsNullOrWhiteSpace(userInput))
            {
                SimulateTyping("Sorry, I didn't catch that. Could you repeat your question?");
                continue;
            }

            if (userInput == "exit" || userInput == "quit" || userInput == "bye" || userInput == "close")
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\nGoodbye! Stay safe online!");
                Console.ResetColor();
                break;
            }

            Console.WriteLine("\n----------------------------------------");

            try
            {
                if (userInput.StartsWith("i'm interested in "))
                {
                    userInterest = userInput.Replace("i'm interested in ", "").Trim();
                    SimulateTyping($"Great! I'll remember that you're interested in {userInterest}. It's a crucial part of staying safe online.");
                    continue;
                }

                if (userInput.Contains("worried"))
                {
                    SimulateTyping("It's completely understandable to feel that way. Scammers can be very convincing. Let me share some tips to help you stay safe.");
                    continue;
                }
                else if (userInput.Contains("curious"))
                {
                    SimulateTyping("Curiosity is great! The more you learn, the safer you'll be online.");
                    continue;
                }
                else if (userInput.Contains("frustrated"))
                {
                    SimulateTyping("I know cybersecurity can seem complex. You're doing great just by asking questions!");
                    continue;
                }

                bool matched = false;

                foreach (var key in randomResponses.Keys)
                {
                    if (userInput.Contains(key))
                    {
                        var responseList = randomResponses[key];
                        string selectedResponse = responseList[random.Next(responseList.Count)];
                        SimulateTyping(userInterest != "" ? $"As someone interested in {userInterest}, here's a tip: {selectedResponse}" : selectedResponse);
                        matched = true;
                        break;
                    }
                }

                if (!matched)
                {
                    foreach (var key in staticResponses.Keys)
                    {
                        if (userInput.Contains(key))
                        {
                            SimulateTyping(staticResponses[key]);
                            matched = true;
                            break;
                        }
                    }
                }

                if (!matched)
                {
                    SimulateTyping("I'm not sure I understand. Can you try rephrasing?");
                }
            }
            catch (Exception ex)
            {
                SimulateTyping($"Oops! Something went wrong: {ex.Message}");
            }

            Console.WriteLine("----------------------------------------\n");
        }
    }

    static void SimulateTyping(string message)
    {
        Console.ForegroundColor = ConsoleColor.White;
        foreach (char c in message)
        {
            Console.Write(c);
            Thread.Sleep(50);
        }
        Console.WriteLine();
        Console.ResetColor();
    }
}

